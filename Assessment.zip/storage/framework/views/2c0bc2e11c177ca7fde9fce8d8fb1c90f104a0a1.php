<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Assessment-256</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>

        </style>
    </head>
    <body>




<div class="container">
  <div class="row justify-content-center">
  	<div class="col-md-8">
    	<div class="card">
    		<div class="card-body">
      			<form name="frmRegistration" method="post" action="AddProfile">
      			<?php echo e(csrf_field()); ?>      
       	 			<div class="form-group row">
          				<div class="col-md-4">
           	 				<h3>Create Your Profile</h3>
            				<label for="fname"><i class="fa fa-user"></i> First Name</label>
            				<input type="text" id="fname" name="firstname" placeholder="John">
            				<label for="lname"><i class="fa fa user"></i>Last Name</label>
            				<input type="text" id="fname" name="lastname" placeholder="Deo">
            				<label for="email"><i class="fa fa-envelope"></i> Email</label>
            				<input type="text" id="email" name="email" placeholder="john@example.com">            				
            				<label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            				<input type="text" id="adr" name="address" placeholder="542 W. 15th Street">
            				<button type="submit" class="btn btn-primary">Add</button>           			
            			</div>
         			</div>
				</form>
			</div>
      	</div>
  	</div>
  </div>	
</div>
<?php /**PATH C:\Users\ultra\eclipse-workspace\Assessment-256\resources\views/Assessment.blade.php ENDPATH**/ ?>