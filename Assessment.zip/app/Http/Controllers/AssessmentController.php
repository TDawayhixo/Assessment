<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Services\Data\AssessmentDAO;
use App\Models\AssessmentModel;



class AssessmentController extends Controller
{
    //To obtain an instance of the current HTTP request from a post
    public function addProfile(Request $request)
    {
        
        $firstname = $request->get('firstname');
        $lastname = $request->get('lastname');
        $email = $request->get('email');
        $address = $request->get('address');
        
        $p = new AssessmentModel($firstname, $lastname, $email, $address);
        
        // Business logic layer
        $service = new AssessmentDAO();
        $result = $service->addProfile($p);
        
        if ($result) {
            
            return view('Assessment');
        }
        
        else {
            echo "failed to add profile";
            return view('home');
        }
    }
    
}