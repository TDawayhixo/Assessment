<?php

namespace App\Services\Data;
use App\Models\AssessmentModel;


error_reporting(E_ALL);
ini_set('display_errors', 1);



class AssessmentDAO
{
    protected $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = "root";
    private $dbname = "assessment-256";
    private $dbQuery;
    private $port = "8889";
    
    public function __construct()
    {
        
        //Creating a connection to database
        $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname, $this->port);
        //make sure to test connection for errors
    }

    public function updateUser(AssessmentModel $p)
    {
        
        $fname = $p->getFName();
        $lname = $p->getLName();
        $email = $p->getEmail();
        $address = $p->getAddress();

        
        
        $sql_statment  = "UPDATE profile SET  First-Name = '$fname', Last-Name ='$lname', Email ='$email', Address ='$address'";
        
        $results = $this->conn()->query($sql_statment);
        
        if ($results) 
        {
            echo "profile was updated";
            return true;
        }
        echo "profile was not updated";
        return false;
        
        
    }
}