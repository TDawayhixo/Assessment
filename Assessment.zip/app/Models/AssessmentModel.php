<?php
namespace App\Models;


class AssessmentModel
{
     
    private $First_Name;
    private $Last_Name;
    private $Email;
    private $Address;
    
    
    function __construct( $First_Name, $Last_Name, $Email, $Address)
    {
        //this is a list of all Form values
        $this->First_Name = $First_Name;
        $this->Last_Name = $Last_Name;
        $this->Email = $Email;
        $this->Address = $Address;

    }
     // these are my getter methods and returning a string for each method    
    public function getFName()
    {
        return $this->First_Name;
    }
    
    public function getLName()
    {
        return $this->Last_Name;
    }
    
    public function getEmail()
    {
        return $this->Email;
    }
    
    public function getAddress()
    {
        return $this->Address;
    }
}